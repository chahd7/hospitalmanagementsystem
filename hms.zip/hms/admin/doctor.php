<?php
session_start();

?>

<!DOCTYPE html>
<html>

<head>
    <title>Total Doctors</title>

</head>

<body>

    <?php
    include('../include/header.php');
    include('../include/connection.php');
    ?>

    <div class="container-fluid">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-2" style="margin-left : -30px;">


                    <?php
                    include('sidenav.php');
                    ?>
                </div>
                <div class="col-md-10">
                    <h5 class = "text-center"> Total Doctors</h5>
                    <?php

                    if (isset($_SESSION['admin'])) {
                        $user = $_SESSION['admin'];

                        $query = "SELECT * FROM employee where emp_id IN (Select F.emp_id from doctor F inner join department D on f.dep_code = d.dep_code where D.emp_id = $user);";
                        $res = pg_query($connect, $query);


                        $output = "";
                        $output .= "
                        <table class='table table-bordered'>
                        <tr>
                        <td>ID</td>
                        <td>First Name</td>
                        <td>Last Name</td>
                        <td>Email</td>
                        <td>Gender</td>
                        <td>Phone</td>
                        <td>Birthday</td>
                        <td>Salary</td>
                 ";

                        if (pg_num_rows($res) < 0) {
                            $output .= "
                    <tr>
                    <td class='text-center' colspan='10'>No Doctors Yet</td>
                    </tr>
                    ";
                        }

                        while ($row = pg_fetch_array($res)) {
                            $output .= "
                    <tr>
                    <td>" . $row['emp_id'] . "</td>
                    <td>" . $row['emp_fname'] . "</td>
                    <td>" . $row['emp_lname'] . "</td>
                    <td>" . $row['emp_email'] . "</td>
                    <td>" . $row['emp_gender'] . "</td>
                    <td>" . $row['emp_phone'] . "</td>
                    <td>" . $row['emp_birthday'] . "</td>
                    <td>" . $row['emp_salary'] . "</td>
                    
                    <td>
                    <a href='edit.php?emp_id=".$row['emp_id']."' >
                    <button class='btn btn-info'>Edit</button>
                    </a>
                    </td>";
                        }
                        $output .= "</tr></table>";
                        echo $output;
                    }
                    ?>

                </div>

            </div>
        </div>
    </div>
</body>

</html>