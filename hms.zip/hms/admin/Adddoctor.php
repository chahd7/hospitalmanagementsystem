<?php
session_start();
?>

<!DOCTYPE html>
<html>

<head>
    <title>Add a doctor</title>
</head>

<body>
    <?php
    include("../include/header.php");
    include("../include/connection.php");
    if (isset($_SESSION['admin'])) {
        $user = $_SESSION['admin'];
    }

    ?>
    <div class="container-fluid">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-2" style="margin-left: -30px;">
                    <?php
                    include("sidenav.php");
                    ?>
                </div>
                <div class="col-md-10">
                    <h5 class="text-center">Add doctor</h5>
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-6">
                                <?php
                                if (isset($_POST['create'])) {
                                    do {
                                        $tempcode = random_int(100000, 999999);
                                        $query  = ("SELECT * FROM employee WHERE emp_id = '$tempcode'");
                                        $res = pg_query($connect, $query);
                                    } while (pg_num_rows($res) != 0);



                                    $error = array();

                                    $lname = $_POST['lname'];
                                    $fname = $_POST['fname'];
                                    $birthday = $_POST['birthday'];
                                    $phone = $_POST['phone'];
                                    $email = $_POST['email'];
                                    $gender = $_POST['gender'];
                                    $salary = $_POST['salary'];
                                    $password = $_POST['password'];
                                    $type = 'D';
                                    $speciality = $_POST['speciality'];
                                    $result = pg_query($connect, "SELECT dep_code FROM Department WHERE emp_id = '$user'");
                                    if ($result) {
                                        // Retrieve the dep_code value from the query result
                                        $row = pg_fetch_assoc($result);
                                        $dep_code = $row['dep_code'];


                                    
                                    $query = "INSERT INTO EMPLOYEE VALUES($tempcode, '$lname', '$fname', '$birthday', '$phone', '$email',  $salary, '$gender', '$password', '$type');";
                                    $qu = "INSERT INTO DOCTOR(emp_id, doc_speciality, dep_code) VALUES ($tempcode, '$speciality', '$dep_code')";
                                    $res = pg_query($connect, $query);
                                    $con =  pg_query($connect, $qu);
                                    if ($res) {
                                         echo "<script>alert('added')</script>";
                                        } else {
                                            echo "<script>alert('failed to add')</script>";
                                        }
                                    }
                                
                                }



                                ?>
                                <form method="post">
                                    <!--<div class="form-group">
                                        <label>Patient Name</label>
                                        <input type="text" name="p_name" class="form-control" placeholder="Enter Patient Name" required>
                                    </div>-->
                                    <div class="form-group">
                                        <label>Last Name</label>
                                        <input type="text" name="lname" class="form-control" placeholder="Enter Doctor Last Name">
                                    </div>
                                    <div class="form-group">
                                        <label>First Name</label>
                                        <input type="text" name="fname" class="form-control" placeholder="Enter Doctor First Name">
                                    </div>
                                    <div class="form-group">
                                        <label>Birthday</label>
                                        <input type="date" name="birthday" class="form-control" required>
                                    </div>
                                    <div class="form-group">
                                        <label>Phone</label>
                                        <input type="text" name="phone" class="form-control" placeholder="Enter phone">
                                    </div>
                                    <div class="form-group">
                                        <label>Email</label>
                                        <input type="text" name="email" class="form-control" placeholder="Enter email">
                                    </div>
                                    <div class="form-group">
                                        <label>Speciality</label>
                                        <input type="text" name="speciality" class="form-control" placeholder="Enter email">
                                    </div>
                                    <div class="form-group">
                                        <label>Gender</label>
                                        <select name="gender" class="form-control" required>
                                            <option value="M">M</option>
                                            <option value="F">F</option>
                                        </select>
                                        <div class="form-group">
                                            <label>Salary</label>
                                            <input type="number" name="salary" class="form-control" placeholder="Enter salary">
                                        </div>
                                        <div class="form-group">
                                            <label>Password</label>
                                            <input type="text" name="password" class="form-control" placeholder="Enter password">
                                        </div>
                                        <input type="submit" name="create" value="Add doctor" class="btn btn-success">
                                </form>
                            </div>
                        </div>
                    </div>
                </div>