<?php
session_start();
?>

<!DOCTYPE html>
<html>

<head>
    <title>Admin Dashboard</title>
</head>

<body>
    <?php
    include("../include/header.php");

    include("../include/connection.php")
    ?>


    <div class="container-fluid">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-2" style="margin-left: -30px;">
                    <?php
                    include("sidenav.php");
                    ?>
                </div>
                <div class="col-md-10">

                    <h4 class="my-2">Admin Dashboard</h4>

                    <div class="col-md-12 my-1">
                        <div class="row">
                            <div class="col-md-3 bg-success mx-2" style="height:130px;">
                                <div class="col-md-12">
                                    <div class="row">
                                        <div class="col-md-8">
                                            <?php
                                            $doc = null;
                                            $count_doc = 0;
                                            if (isset($_SESSION['admin'])) {
                                                $user = $_SESSION['admin'];

                                                $doc = pg_query($connect, "Select * from doctor D where D.dep_code = (Select Dep_code from Department where emp_id = $user);");
                                                $count_doc = pg_num_rows($doc);
                                            }
                                            ?>
                                            <h5 class="my-2 text-white" style="font-size:30px;"><?php echo $count_doc; ?></h5>
                                            <h5 class="text-white">Total</h5>
                                            <h5 class="text-white">Doctors</h5>
                                        </div>
                                        <div class="col-md-4">
                                            <a href="doctor.php"><i class="fa fa-user-md fa-3x my-4" style="color : white;"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-3 bg-info mx-2" style="height:130px;">
                                <div class="col-md-12">
                                    <div class="row">
                                        <div class="col-md-8">
                                            <?php
                                            $patient = null;
                                            $count_patient = 0;
                                            if (isset($_SESSION['admin'])) {
                                                $user = $_SESSION['admin'];
                                                //need to fix
                                                $patient = pg_query($connect, "Select * from appointment P where P.emp_id IN (Select E.emp_id from doctor E inner join department D on E.dep_code = D.dep_code where D.emp_id = $user);");
                                                $count_patient = pg_num_rows($patient);
                                            }
                                            ?>
                                            <h5 class="my-2 text-white" style="font-size:30px;"><?php echo $count_patient; ?></h5>
                                            <h5 class="text-white">Total</h5>
                                            <h5 class="text-white">Appointments</h5>
                                        </div>
                                        <div class="col-md-4">
                                            <a href="#"><i class="fa fa-procedures fa-3x my-4" style="color : white;"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-3 bg-warning mx-2" style="height:130px;">
                                <div class="col-md-12">
                                    <div class="row">
                                        <div class="col-md-8">
                                        <?php
                                            
                                            $count_reports = 0;
                                            if (isset($_SESSION['admin'])) {
                                                $user = $_SESSION['admin'];
                                                $patient = pg_query($connect, "Select * from appointment P where P.status = 'Completed' AND P.emp_id IN (Select E.emp_id from doctor E inner join department D on E.dep_code = D.dep_code where D.emp_id = $user);");
                                                $count_reports = pg_num_rows($patient);
                                            }
                                            ?>
                                            <h5 class="my-2 text-white" style="font-size:30px;"><?php echo $count_reports; ?></h5>
                                            <h5 class="text-white">Total</h5>
                                            <h5 class="text-white">Reports</h5>
                                        </div>
                                        <div class="col-md-4">
                                            <a href="#"><i class="fa fa-flag fa-3x my-4" style="color : white;"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                           

                            <!-- <div class="col-md-3 bg-warning mx-2 my-2" style="height:130px;">

                            </div>

                            <div class="col-md-3 bg-success mx-2 my-2" style="height:130px;">

                            </div>-->

                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>
</body>

</html>