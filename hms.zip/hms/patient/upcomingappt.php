<?php
session_start();

?>

<!DOCTYPE html>
<html>

<head>
    <title>Total Appointments</title>

</head>

<body>

    <?php
    include('../include/header.php');
    include('../include/connection.php');
    ?>

    <div class="container-fluid">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-2" style="margin-left : -30px;">
                    <?php
                    include('sidenav.php');
                    ?>
                </div>
                <div class="col-md-10">
                    <?php
                    if (isset($_SESSION['patient'])) {
                        $user = $_SESSION['patient'];

                        $query = "SELECT * FROM appointment where patient_id = $user and status = 'upcoming';";
                        $res = pg_query($connect, $query);


                        $output = "";
                        $output .= "
                        <table class='table table-bordered'>
                        <tr>
                        <td>ID</td>
                        <td>Doctor</td>
                        <td>Date</td>
                        <td>Type</td>
                        <td>Symptoms</td>
                        <td>Status</td>
                 ";

                        if (pg_num_rows($res) < 0) {
                            $output .= "
                    <tr>
                    <td class='text-center' colspan='10'>No Appointment Yet</td>
                    </tr>
                    ";
                        }

                        while ($row = pg_fetch_array($res)) {
                            $output .= "
                    <tr>
                    <td>" . $row['appointment_id'] . "</td>
                    <td>" . $row['emp_id'] . "</td>
                    <td>" . $row['appointment_date'] . "</td>
                    <td>" . $row['appointment_time'] . "</td>
                    <td>" . $row['appointment_description'] . "</td>
                    <td>" . $row['status'] . "</td>
                    
                    <td>
                    <a href='delete.php?appointment_id=" . $row['appointment_id'] . "' >
                    </a>
                    </td>";

                        }
                        $output .= "</tr></table>";
                        echo $output;

                    }
                    ?>

                </div>

            </div>
        </div>
    </div>
</body>

</html>