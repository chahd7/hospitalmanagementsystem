<?php

session_start();

?>

<!DOCTYPE html>
<html>

<head>
    <title></title>
</head>

<body>


    <?php
    include("../include/header.php");
    include("../include/connection.php");
    ?>


    <div class="container-fluid">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-2" style="margin-left: -30px;">
                    <?php
                    include("sidenav.php");
                    ?>
                </div>
                <div class="col-md-10">
                    <?php
                    if (isset($_GET['appointment_id'])) {
                        $id = $_GET['appointment_id'];
                    }
                    ?>


                </div>
                <?php
                if (isset($_POST['delete'])) {
                    $query = "Delete from Appointment where appointment_id = '$id'";
                    pg_query($connect, $query);
                    echo "<script>alert('Successfully deleted')</script>";
                }
                ?>


            </div>
        </div>
    </div>
</body>

</html>