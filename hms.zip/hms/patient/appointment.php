<?php
session_start();
?>

<!DOCTYPE html>
<html>

<head>
    <title>Book Appointment</title>
</head>

<body>
    <?php
    include("../include/header.php");
    include("../include/connection.php");
    if(isset($_SESSION['patient'])){
        $user = $_SESSION['patient'];}

    ?>
    <div class="container-fluid">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-2" style="margin-left: -30px;">
                    <?php
                    include("sidenav.php");
                    ?>
                </div>
                <div class="col-md-10">
                    <h5 class="text-center">Book Appointment</h5>
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-6">
                                <?php
                                    if (isset($_POST['create'])) {
                                        do {
                                            $tempcode = random_int(100000, 999999);
                                            $query  = ("SELECT * FROM appointment WHERE appointment_id = '$tempcode'");
                                            $res = pg_query($connect, $query);
                                        } while (pg_num_rows($res) != 0);

                                        //$code = strval($tempcode);

                                        $error = array();

                                        $dname = $_POST['d_name'];
                                        $date = $_POST['date'];
                                        $time = $_POST['time'];
                                        $reason = $_POST['reason'];
                                        $status = 'upcoming';

                                        if (empty($dname)) {
                                            $error['ap'] = "enter doctor name";
                                        } else if (empty($date)) {
                                            $error['ap'] = "enter date";
                                        } else if (empty($time)) {
                                            $error['ap'] = "enter time";
                                        }


                                        $query = "Select emp_id from employee where emp_lname = '$dname' and emp_type = 'D'";
                                        $test = pg_query($connect, $query);

                                        if (pg_num_rows($test) == 0) {
                                            $error['ap'] = "doctor doesn't exist";
                                            echo "<script>alert('doctor doesn't exist')</script>";
                                        } else {
                                            $row = pg_fetch_assoc($test);
                                            $docid = $row['emp_id'];
                                        }

                                        if (count($error) == 0) {
                                            $query = "INSERT INTO appointment(appointment_id, patient_id, emp_id, appointment_date, appointment_time, appointment_description, status) 
                                           VALUES ($tempcode, $user, $docid, '$date', '$time', '$reason', '$status')";
                                            $res = pg_query($connect, $query);
                                            if ($res) {
                                                echo "<script>alert('booked')</script>";
                                            } else {
                                                echo "<script>alert('failed to book')</script>";
                                            }
                                        }
                                    }
                            
                                


                                ?>
                                <form method="post">
                                    <!--<div class="form-group">
                                        <label>Patient Name</label>
                                        <input type="text" name="p_name" class="form-control" placeholder="Enter Patient Name" required>
                                    </div>-->
                                    <div class="form-group">
                                        <label>Doctor Last Name</label>
                                        <input type="text" name="d_name" class="form-control" placeholder="Enter Doctor Name">
                                    </div>
                                    <div class="form-group">
                                        <label>Date</label>
                                        <input type="date" name="date" class="form-control" required>
                                    </div>
                                    <div class="form-group">
                                        <label>Time</label>
                                        <input type="time" name="time" class="form-control" required>
                                    </div>
                                    <div class="form-group">
                                        <label>Reason for Appointment</label>
                                        <input type="text" name="reason" class="form-control" placeholder="Enter Reason for Appointment" required></textarea>
                                    </div>
                                    <input type="submit" name="create" value="Book an appointment" class="btn btn-success">
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>