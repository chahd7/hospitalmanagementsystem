
<!DOCTYPE html>
<html>

<head>
    <title></title>
</head>

<body>

    <!--side nav-->
    <div class="list-group bg-info" style="height: 90vh;">
        <a href="index.php" class="list-group-item list-group-item-action bg-info text-center text-white">Dashboard</a>
        <a href="profile.php" class="list-group-item list-group-item-action bg-info text-center text-white">Profile</a>
        <a href="appointment.php" class="list-group-item list-group-item-action bg-info text-center text-white">Book Appointment</a>
        <a href="upcomingappt.php" class="list-group-item list-group-item-action bg-info text-center text-white">Upcoming appointments</a>
        <a href="report.php" class="list-group-item list-group-item-action bg-info text-center text-white">Report</a>
    </div>

    <!--ends-->

</body>


</html>