<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Patient's Dashboard</title>
</head> 
<body>
    <?php include("../include/header.php"); ?>
   
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-2" style="margin-left: -30px;">
            <?php include("sidenav.php"); ?>
            </div>
            <div class="col-md-10">
                <div class="container-fluid">
                    <h5>Patient's Dashboard</h5>
                    <div class="col-md-12"> 
                        <div class="row">
                            <div class="col-md-4 my-3">
                                <div class="bg-info text-white p-3" style="height: 150px;">
                                    <h5>My Profile</h5>
                                    <a href="profile.php"><i class="fa fa-user-circle fa-3x my-4 text-white"></i></a>
                                </div>
                            </div>

                            <div class="col-md-4 my-3">
                                <div class="bg-success text-white p-3" style="height: 150px;">
                                    <h5>Book Appointment</h5>
                                    <a href="appointment.php"><i class="fa fa-calendar fa-3x my-4 text-white"></i></a>
                                </div>
                            </div>

                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
