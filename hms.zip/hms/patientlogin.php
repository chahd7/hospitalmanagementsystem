<?php
session_start();
?>

<?php
include("include/connection.php");

if (isset($_POST['login'])) {
    $username = $_POST['uname'];
    $password = $_POST['pass'];

    $error = array();

    if (empty($username)) {
        $error['patient'] = "Enter ID";
    } else if (empty($password)) {
        $error['patient'] = "Enter Password";
    }

    if (count($error) == 0) {
        $query = "SELECT * FROM patient WHERE patient_id = '$username' AND password = '$password'";
        $result = pg_query($connect, $query);

        if (pg_num_rows($result) == 1) {
            echo "<script>alert('Welcome back, Patient!')</script>";

            $_SESSION['patient'] = $username;
            header("Location: patient/index.php");
            
            exit(); 
        } else {
            echo "<script>alert('Invalid ID or password')</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Patient's Login Page</title>
</head>

<body>
    <?php
    include("include/header.php");
    ?>

    <div style="margin-top: 20px;background-repeat: no-repeat;background-size: cover;"></div>

    <div class="container">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-3"></div>
                <div class="col-md-6 jumbotron">
                    <img src="img/admin.png" class="col-md-12" style="width:30%;">
                    <form method="post">
                        <div>
                            <?php
                            if (isset($error['patient'])) {
                                $sh = $error['patient'];
                                $show = "<h4 class='alert alert-danger'>$sh</h4>";
                            } else {
                                $show = "";
                            }
                            echo $show;
                            ?>
                        </div>

                        <div class="form-group">
                            <label>Username</label>
                            <input type="text" name="uname" placeholder="Enter ID" class="form-control" autocomplete="off" required>
                        </div>
                        <div class="form-group">
                            <label>Password</label>
                            <input type="password" name="pass" placeholder="Enter password" class="form-control" autocomplete="off" required>
                        </div>

                        <input type="submit" name="login" value="Login" class="btn btn-success">
                    
                        <p>Don't have an account? <a href="account.php">Click here</a></p>
                    </form>
                </div>
                <div class="col-md-3"></div>
            </div>
        </div>
    </div>

</body>

</html>
