<?php

include("include/connection.php");
if (isset($_POST['create'])) {
    do {
        $id = random_int(100000, 999999);
        $query  = ("SELECT * FROM patient WHERE patient_id = $id");
        $res = pg_query($connect, $query);
    } while (pg_num_rows($res) != 0);

    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $gender = $_POST['gender'];
    $insurrance = $_POST['insurrance'];
    $pass = $_POST['pass'];
    $con_pass = $_POST['con_pass'];


    $error = array();

    if (empty($fname)) {
        $error['ac'] = "enter first name";
    } else if (empty($lname)) {
        $error['ac'] = "enter last name";
    } else if (empty($email)) {
        $error['ac'] = "enter email";
    } else if (empty($phone)) {
        $error['ac'] = "enter phone";
    } else if (empty($address)) {
        $error['ac'] = "enter address";
    } else if ($gender == "") {
        $error['ac'] = "Select your gender";
    } else if (empty($insurrance)) {
        $error['ac'] = "enter insurrance number";
    } else if (empty($pass)) {
        $error['ac'] = "enter password";
    } else if ($con_pass != $pass) {
        $error['ac'] = "passwords do not match";
    }

    if (count($error) == 0) {
        $query = "INSERT INTO Patient(patient_id, patient_lname, patient_fname, patient_email, patient_phone, patient_address, patient_gender,
patient_insurrancenum, password) VALUES ($id, '$lname', '$fname', '$email', '$phone', '$address', '$gender', '$insurrance', '$pass')";
        $res = pg_query($connect, $query);
        if ($res) {
            echo "<script>alert('Your id is $id')</script>";
            header("Location:patientlogin.php");
        } else {
            echo "<script>alert('failed to signup')</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Account</title>
    <link rel="stylesheet" type="text/css" href="css/account.css">
</head>

<body>
    <?php
    include("include/header.php");
    ?>

    <div class="container-fluid">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-3"></div>
                <div class="col-md-6 my-2 jumbotron">
                    <h5 class="text-center tex-info my-2">Create Account</h5>

                    <form method="post">

                        <div class="form-group">
                            <label>First Name</label>
                            <input type="text" name="fname" class="form-control" autocomplete="off" placeholder="Enter First Name" required>
                        </div>
                        <div class="form-group">
                            <label>Last Name</label>
                            <input type="text" name="lname" class="form-control" autocomplete="off" placeholder="Enter Last Name" required>
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input type="text" name="email" class="form-control" autocomplete="off" placeholder="Enter Email" required>
                        </div>
                        <div class="form-group">
                            <label>Phone</label>
                            <input type="text" name="phone" class="form-control" autocomplete="off" placeholder="Enter Phone" required>
                        </div>
                        <div class="form-group">
                            <label>Address</label>
                            <input type="text" name="address" class="form-control" autocomplete="off" placeholder="Enter Address" required>
                        </div>
                        <div class="form-group">
                            <label>Gender</label>
                            <select name="gender" class="form-control" required>
                                <option value="M">Male</option>
                                <option value="F">Female</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Insurrance Number</label>
                            <input type="text" name="insurrance" class="form-control" autocomplete="off" placeholder="Enter Insurance Number" required>
                        </div>
                        <div class="form-group">
                            <!--<label>Status</label>
                            <select name="patient_status" class="form-control" required>
                                <option value="D">Deactivated</option>
                                <option value="A">Activated</option>
                            </select>-->
                        </div>
                        <div class="form-group">
                            <label>Password</label>
                            <input type="password" name="pass" class="form-control" autocomplete="off" placeholder="Enter Password" required>
                        </div>

                        <div class="form-group">
                            <label>Confirm Password</label>
                            <input type="password" name="con_pass" class="form-control" autocomplete="off" placeholder="Enter Password" required>
                        </div>

                        <input type="submit" name="create" value="Create Account" class="btn btn-success">
                        <p>I already have an account <a href="patientlogin.php">Click here</a></p>
                    </form>
                </div>
                <div class="col-md-3"></div>
            </div>
        </div>
    </div>

</body>

</html>