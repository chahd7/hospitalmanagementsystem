<!DOCTYPE html>

<html>

<head>
    <title>HMS Home Page</title>
</head>

<body>

    <?php
    include("include/header.php");
    ?>

    <div style="margin-top: 50px"></div>

    <div class="container">
        <div class="col-md-20">
            <div class="row">
                <div class="col-md-3 mx-1 shadow">
                    <img src="img/info.jpg" style="width:100%;">
                    <h5 class="text-center">Learn more about us !</h5>

                    <a href="#">
                        <button class="btn btn-success my-3" style="margin-left:20%;">More Information </button>
                    </a>


                </div>
                <div class="col-md-4 mx-1 shadow">
                    <img src="img/patient.jpg" style="width:100%;">
                    <h5 class="text-center">Let us take care of you by creating an account !</h5>

                    <a href="account.php">
                        <button class="btn btn-success my-3" style="margin-left:30%;">Create an account </button>
                    </a>

                </div>

                <div class="col-md-4 mx-1 shadow">
                    <img src="img/doctor.avif" style="width:100%;">
                    <h5 class="text-center">Our doctors</h5>

                    <a href="#">
                        <button class="btn btn-success my-3" style="margin-left:30%;">Know more ! </button>
                    </a>

                </div>
            </div>
        </div>
    </div>
</body>

</html>