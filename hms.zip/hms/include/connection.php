<?php

$host = "localhost";
$port = "5432";
$dbname = "hospital";
$user = "hospital";
$password = "maatallaouic";

// Create connection
$connect = pg_connect("host=localhost port=5432 dbname=hospital user=hospital password=maatallaouic");

// Check connection
//if ($cn) {
  //  echo "Connected successfully";
//}



?>