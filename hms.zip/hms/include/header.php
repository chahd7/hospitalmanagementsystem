<!doctype html>
<html lang="en">

<head>
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js" integrity="sha384-Vk1ATqbUeFXadpBpU8BqFv6FAR2Pwlzn1z9FEb3NGbWpitY1gUar7Mv5q4oG2I6B" crossorigin="anonymous"></script>
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/js/all.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-info" style="background-color:#F4C2C2;">
        <h5 class="text-white">Care Connect - Hospital management system</h5>

        <div class="mr-auto"></div>

        <ul class="navbar-nav">

            <?php
            

            if (isset($_SESSION['admin'])) {
                $user = $_SESSION['admin'];
                echo '
                <li class="nav-item"><a href="#" class="nav-link text-white">' . $user . '</a></li>
                <li class="nav-item"><a href="logout.php" class="nav-link text-white">logout</a></li>';

            } 
            else if(isset($_SESSION['doctor'])){
                $user = $_SESSION['doctor'];
                echo '
                <li class="nav-item"><a href="#" class="nav-link text-white">' . $user . '</a></li>
                <li class="nav-item"><a href="logout.php" class="nav-link text-white">logout</a></li>';
            }
            else if(isset($_SESSION['patient'])){
                $user = $_SESSION['patient'];
                echo '
                <li class="nav-item"><a href="#" class="nav-link text-white">' . $user . '</a></li>
                <li class="nav-item"><a href="logout.php" class="nav-link text-white">logout</a></li>';
            }
            else {
                echo '
                <li class="nav-item"><a href="index.php" class="nav-link text-white">Home</a></li>
                <li class="nav-item"><a href="adminlogin.php" class="nav-link text-white">Admin</a></li>
                <li class="nav-item"><a href="doctorlogin.php" class="nav-link text-white">Doctor</a></li>
                <li class="nav-item"><a href="patientlogin.php" class="nav-link text-white">Patient</a></li>';
            }
            ?>

        </ul>

    </nav>

</body>

</html>
