<?php
session_start();

?>

<!DOCTYPE html>
<html>

<head>
    <title>Past appointments</title>

</head>

<body>

    <?php
    include('../include/header.php');
    include('../include/connection.php');
    ?>

    <div class="container-fluid">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-2" style="margin-left : -30px;">
                    <?php
                    include('sidenav.php');
                    ?>
                </div>
                <div class="col-md-10">
                    <?php
                    if (isset($_SESSION['doctor'])) {
                        $user = $_SESSION['doctor'];

                        $query = "SELECT * FROM appointment where emp_id = $user and status = 'Completed';";
                        $res = pg_query($connect, $query);


                        $output = "";
                        $output .= "
                        <table class='table table-bordered'>
                        <tr>
                        <td>ID</td>
                        <td>Patient</td>
                        <td>Date</td>
                        <td>Time</td>
                        <td>Description</td>
                        <td>Price</td>
                        <td>Bilan</td>
                 ";

                        if (pg_num_rows($res) < 0) {
                            $output .= "
                    <tr>
                    <td class='text-center' colspan='10'>No Appointment Yet</td>
                    </tr>
                    ";
                        }

                        while ($row = pg_fetch_array($res)) {
                            $output .= "
                    <tr>
                    <td>" . $row['appointment_id'] . "</td>
                    <td>" . $row['patient_id'] . "</td>
                    <td>" . $row['appointment_date'] . "</td>
                    <td>" . $row['appointment_time'] . "</td>
                    <td>" . $row['appointment_description'] . "</td>
                    <td>" . $row['appointment_price'] . "</td>
                    <td>" . $row['appointment_bilan'] . "</td>
                    
                    <td>

                    </td>";

                        }
                        $output .= "</tr></table>";
                        echo $output;

                    }
                    ?>

                </div>

            </div>
        </div>
    </div>
</body>

</html>