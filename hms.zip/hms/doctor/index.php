<?php
session_start();
?>

<!DOCTYPE html>
<html>

<head>
    <title>Doctor's Dashboard</title>
</head>

<body>
    <?php include("../include/header.php");
    include("../include/connection.php") ?>

    <div class="container-fluid">
        <div class="row">
            <div class="col-md-2" style="margin-left: -30px;">
                <?php include("sidenav.php"); ?>
            </div>
            <div class="col-md-10">
                <div class="container-fluid">
                    <h5>Doctor's Dashboard</h5>
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-4 my-3">
                                <div class="bg-info text-white p-3" style="height: 150px;">
                                    <h5>My Profile</h5>
                                    <a href="profile.php"><i class="fa fa-user-circle fa-3x my-4 text-white"></i></a>
                                </div>
                            </div>

                            <div class="col-md-4 my-3">
                                <div class="bg-success text-white p-3" style="height: 150px;">
                                <?php
                                            $patient=null;
                                            $count_patient = 0;
                                            if (isset($_SESSION['doctor'])) {
                                                $user = $_SESSION['doctor'];
                    
                                             $patient = pg_query($connect, "Select * from appointment where emp_id = $user;");
                                            $count_patient = pg_num_rows($patient);
                                            }
                                            ?>
                                            <h5 class="my-1 text-white" style="font-size:30px;"><?php echo $count_patient;?></h5>
                                    <h5>Total Appointments</h5>
                                    <a href="appointment.php"><i class="fa fa-calendar fa-3x my-1 text-white"></i></a>
                                </div>
                            </div>

                            <div class="col-md-4 my-3">
                                <div class="bg-warning text-white p-3" style="height: 150px;">
                                <?php
                                            $patient=null;
                                            $count_patient = 0;
                                            if (isset($_SESSION['doctor'])) {
                                                $user = $_SESSION['doctor'];
                    
                                             $patient = pg_query($connect, "Select * from appointment where emp_id = $user;");
                                            $count_patient = pg_num_rows($patient);
                                            }
                                            ?>
                                            <h5 class="my-1 text-white" style="font-size:30px;"><?php echo $count_patient;?></h5>
                                    <h5>Total Patients</h5>
                                    <a href="patient.php"><i class="fa fa-users fa-3x my-1 text-white"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>