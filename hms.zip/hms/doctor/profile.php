<?php
session_start();
?>
<!DOCTYPE html>
<html>

<head>
    <title>Doctor Profile</title>
    <style>
        /* Add custom styling here */
        body {
            font-family: Arial, sans-serif;
        }

        .profile-title {
            text-align: center;
            font-size: 24px;
            font-weight: bold;
            margin-top: 30px;
            margin-bottom: 20px;
        }

        .profile-table {
            width: 100%;
            margin-top: 30px;
            border-spacing: 20px 10px;
        }

        .profile-table td {
            padding: 10px;
        }

        .profile-table .pink-row {
            background-color: #FFD1DC;
        }

        .profile-table .blue-row {
            background-color: #C9E5FF;
        }

        .section-title {
            font-size: 20px;
            font-weight: bold;
            margin-top: 40px;
            margin-bottom: 10px;
        }

        .change-password-section {
            background-color: #E1F2FE;
            padding: 20px;
            margin-bottom: 30px;
        }

        .change-info-section {
            background-color: #FFE7ED;
            padding: 20px;
        }

        .form-label {
            font-weight: bold;
        }

        .row {
            display: flex;
            margin-left: -15px;
            margin-right: -15px;
        }

        .col-md-6 {
            flex: 0 0 50%;
            max-width: 50%;
            padding-left: 15px;
            padding-right: 15px;
        }

        .container {
            display: flex;
            flex-direction: row;
        }

        .sidenav {
            background-color: #f1f1f1;
            width: 200px;
            padding: 20px;
        }
    </style>


</head>

<body>
    <?php
    include("../include/header.php");
    include("../include/connection.php");

    $ad = $_SESSION['doctor'];
    $query = "SELECT * FROM employee WHERE emp_id = '$ad'";

    $res = pg_query($connect, $query);

    while($row = pg_fetch_array($res)){
        $first_name = $row['emp_fname'];
       $last_name = $row['emp_lname'];
       $email = $row['emp_email'];
       $phone = $row['emp_phone'];
       $gender = $row['emp_gender'];
       $type = $row['emp_type'];
    }
    ?>


    <div class="content">
        <h2 class="profile-title">Doctor's Profile</h2>
        <div class="row">
            <div class="col-md-2" style="margin-left: -30px; margin-top : -80px;">
                <?php include("sidenav.php"); ?> </div>
            <div class="col-md-6">
                <table class="profile-table">
                    <tr class="pink-row">
                        <td><strong>First Name:</strong></td>
                        <td>
                            <?php  echo $first_name; 
                            ?></td>
                        </td>
                    </tr>
                    <tr class="blue-row">
                        <td><strong>Last Name:</strong></td>
                        <td><?php echo $last_name; 
                            ?></td>
                    </tr>
                    <tr class="pink-row">
                        <td><strong>Email:</strong></td>
                        <td><?php  echo $email; 
                            ?></td>
                    </tr>
                    <tr class="blue-row">
                        <td><strong>Phone:</strong></td>
                        <td><?php  echo $phone; 
                            ?></td>
                    </tr>
                    <tr class="pink-row">
                        <td><strong>Gender:</strong></td>
                        <td><?php echo $gender; 
                            ?></td>
                    </tr>

                    <tr class="blue-row">
                        <td><strong>Type:</strong></td>
                        <td><?php echo $type; 
                            ?></td>
                    </tr>
                    <!-- Add more profile information as desired -->
                </table>
            </div>
            <div class="col-md-4">
                <div class="change-password-section">
                    <h5 class="section-title">Change Password</h5>
                    <?php
                    if (isset($_POST['update_pass'])) {

                        $old_pass = $_POST['old_pass'];
                        $new_pass = $_POST['new_pass'];
                        $con_pass = $_POST['con_pass'];

                        $error = array();

                        $old = pg_query($connect, "Select * from EMPLOYEE where emp_id = $ad");
                        $row = pg_fetch_array($old);
                        $pass = $row['password'];

                        

                        if(empty($old_pass)){
                            $error['p'] = "Enter old password";
                            echo "<script>alert('Enter old password')</script>";
                        }else if(empty($new_pass)){
                            $error['p'] = "Enter new password";
                            echo "<script>alert('Enter new password')</script>";
                        }else if(empty($con_pass)){
                            $error['p'] = "Confirm password";
                        }else if($old_pass != $pass){
                            $error['p'] = "Invalid old password";
                            echo "<script>alert('Invalid old password')</script>";
                        }else if($new_pass != $con_pass){
                            $error['p'] = "Passwords don't match";
                            echo "<script>alert('Passwords don't match')</script>";
                        }

                        if(count($error) == 0) {
                            $query = "Update Employee SET password = '$new_pass' where emp_id = $ad";
                            $res = pg_query($connect, $query);
                            //need to include some message
                            echo "<script>alert('Password changed')</script>";
                        }

                        


                    }
                    ?>
                    <form method="post">
                        <label class="form-label">Enter Old Password</label>
                        <input type="password" name="old_password" class="form-control" autocomplete="off" placeholder="Enter Old Password">
                        <br />
                        <label class="form-label">Enter New Password</label>
                        <input type="password" name="new_pass" class="form-control" autocomplete="off" placeholder="Enter New Password">
                        <br />
                        <label class="form-label">Confirm New Password</label>
                        <input type="password" name="con_pass" class="form-control" autocomplete="off" placeholder="Confirm New Password">
                        <br />
                        <input type="submit" name="update_password" class="btn btn-primary" value="Change Password" />
                    </form>
                </div>
                <div class="change-info-section">
                    <h5 class="section-title">Change Info</h5>
                    <?php
                    if (isset($_POST['change'])) {
                        $firstname = $_POST['firstname'];

                        $lastname = $_POST['lastname'];

                        $empemail = $_POST['email'];

                        $empphone = $_POST['phone'];

                        //first name update
                        if (empty($firstname)) {
                        } else {
                            $query = "UPDATE EMPLOYEE set emp_fname = '$firstname' where emp_id = $ad";
                            $res = pg_query($connect, $query);
                        }

                        if ($res) {
                            $first_name = $firstname;
                        }
                        //last name update 
                        if (empty($lastname)) {
                        } else {
                            $query = "UPDATE EMPLOYEE set emp_lname = '$lastname' where emp_id = $ad";
                            $res = pg_query($connect, $query);
                            if ($res) {
                                $last_name = $lastname;
                            }
                        }
                        //email update 
                        if (empty($empemail)) {
                        } else {
                            $query = "UPDATE EMPLOYEE set emp_email = '$empemail' where emp_id = $ad";
                            $res = pg_query($connect, $query);
                            if ($res) {
                                $email = $empemail;
                            }
                        }

                        //phone update 

                        if (empty($empphone)) {
                        } else {
                            $query = "UPDATE EMPLOYEE set emp_phone = '$empphone' where emp_id = $ad";
                            $res = pg_query($connect, $query);
                            if ($res) {
                                $phone = $empphone;
                            }
                        }
                    }
                    ?>
                    <form method="post">
                        <label class="form-label">Change First Name</label>
                        <input type="text" name="firstname" class="form-control" autocomplete="off" placeholder="Enter First Name">
                        <br />
                        <label class="form-label">Change Last Name</label>
                        <input type="text" name="lastname" class="form-control" autocomplete="off" placeholder="Enter Last Name">
                        <br />
                        <label class="form-label">Change Email</label>
                        <input type="email" name="email" class="form-control" autocomplete="off" placeholder="Enter Email">
                        <br />
                        <label class="form-label">Change Phone</label>
                        <input type="text" name="phone" class="form-control" autocomplete="off" placeholder="Enter Phone">
                        <br />
                        <input type="submit" name="change" class="btn btn-primary" value="Change Info" />
                    </form>
                </div>
            </div>
        </div>

    </div>
    </div>
</body>

</html>