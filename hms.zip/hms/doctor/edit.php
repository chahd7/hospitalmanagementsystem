<?php

session_start();

?>

<!DOCTYPE html>
<html>

<head>
    <title>Edit Doctor</title>
</head>

<body>


    <?php
    include("../include/header.php");
    include("../include/connection.php");
    ?>


    <div class="container-fluid">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-2" style="margin-left: -30px;">
                    <?php
                    include("sidenav.php");
                    ?>
                </div>
                <div class="col-md-10">
                    <h5 class="text-center">Edit Appointment</h5>

                    <?php
                    if (isset($_GET['appointment_id'])) {
                        $id = $_GET['appointment_id'];

                        $query = "SELECT * FROM appointment WHERE appointment_id = '$id'";
                        $res = pg_query($connect, $query);

                        $row = pg_fetch_array($res);
                        
                    }
                    ?>
                    <div class="row">
                        <div class="col-md-8">
                            <h5 class="text-center">Appointment Details</h5>
                            <h5 class="my-3">ID : <?php echo $row['appointment_id']; ?></h5>
                            <h5 class="my-3">Patient ID : <?php echo $row['patient_id']; ?></h5>
                            <h5 class="my-3">Reasons : <?php echo $row['appointment_description']; ?></h5>
                            <h5 class="my-3">Date : <?php echo $row['appointment_date']; ?></h5>
                            <h5 class="my-3">Time : <?php echo $row['appointment_time']; ?></h5>
                            <h5 class="my-3">Status : <?php echo $row['status']; ?></h5>

                        </div>
                        <div class="col-md-4">
                            <h5 class='text-center'>Update status</h5>
                            <?php 
                            if(isset($_POST['update'])){
                                $price = $_POST['price'];
                                $status = 'Completed';
                                $bilan = $_POST['bilan'];
                                $query = "Update Appointment set appointment_price = $price where appointment_id = '$id'";
                                $q = "Update Appointment set status = '$status' where appointment_id = '$id'";
                                $qu = "Update Appointment set appointment_bilan = '$bilan' where appointment_id = '$id'";
                                pg_query($connect, $query);
                                pg_query($connect, $q);
                                pg_query($connect, $qu);
                            }
                            ?>
                            <form method = "Post">
                            <input type="number" name="price" class="form-control" autocomplete="off" placeholder="enter the price of the appointment" required>
                            <textarea name="bilan" class="form-control" autocomplete="off" placeholder="enter the bilan" required></textarea>
                                <input type="submit" name = "update" class = "btn btn-info my-3" value = "Update Status"> 
                            </form>
                        </div>
                    </div>
                </div>
            </div>
</body>

</html>