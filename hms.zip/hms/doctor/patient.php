<?php
session_start();
?>

<!DOCTYPE html>
<html>

<head>
    <title>Total Patients</title>
</head>

<body>
    <?php
    include('../include/header.php');
    include('../include/connection.php');
    ?>

    <div class="container-fluid">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-2" style="margin-left: -30px;">
                    <?php
                    include('sidenav.php');
                    ?>
                </div>
                <div class="col-md-10">
                
                </div>
            </div>
        </div>
    </div>
</body>

</html>
